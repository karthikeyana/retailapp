'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
var CUSTOMER_MODEL = exports.CUSTOMER_MODEL = 'customers';
var PRODUCT_MODEL = exports.PRODUCT_MODEL = 'products';