'use strict';

export const CUSTOMER_MODEL = 'customers';
export const PRODUCT_MODEL = 'products';

